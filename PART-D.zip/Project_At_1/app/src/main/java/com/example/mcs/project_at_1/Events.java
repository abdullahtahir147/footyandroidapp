package com.example.mcs.project_at_1;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.TextView;

import java.util.ArrayList;

public class Events extends AppCompatActivity {

    Intent intentThatStartedThisActivity;
    String   forecastStr;
    private TextView mScoreInfo;
    private TextView played;
    private TextView Won;
    private TextView Lost;
    private TextView Drawn;
    private TextView TotalPoints;



    public static String[] results = {""};
    Adapter cAdapter;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.events_layout);







        mScoreInfo  = (TextView) findViewById(R.id.t1);
        played = findViewById(R.id.t);
        Won= findViewById(R.id.t5);
        Lost = findViewById(R.id.t2);
        Drawn = findViewById(R.id.t3);
        TotalPoints = findViewById(R.id.t4);


        intentThatStartedThisActivity = getIntent();

//        if (intentThatStartedThisActivity.hasExtra(Intent.EXTRA_TEXT)){

//            forecastStr = intentThatStartedThisActivity.getStringExtra(Intent.EXTRA_TEXT);
            Bundle bundle = intentThatStartedThisActivity.getExtras();
            forecastStr = bundle.getString("team");
            String URLString = "https://apifootball.com/api/?action=get_standings&league_id=63&APIkey=31f3ab8b35f9cba898baae6868908741cf2d855b04af85b033220142dec20886";






        String[] Items = {"pls"};
//            cAdapter = new Adapter(Items.length, Items, this);

            Log.v("DetailActivity.onCreate", forecastStr.substring(3,forecastStr.length()));
            int position = Integer.parseInt(bundle.getString("number"));

            Intent goServiceOne = new Intent(Events.this, MyIntentService2.class);
            Bundle sendBundle = new Bundle();
            sendBundle.putString("URL", URLString);
            sendBundle.putInt("position", position);
            goServiceOne.putExtra("bundle", sendBundle);
            this.startService(goServiceOne);


//            FetchTask2 json = new FetchTask2(results, this.getApplicationContext(), position);
//            json.execute(URLString);
            try{
                played.setText(results[0]);
                Won.setText(results[1]);
                Lost.setText(results[2]);
                Drawn.setText(results[3]);
                TotalPoints.setText(results[4]);



            }catch (ArrayIndexOutOfBoundsException e){
                Log.e("ERROR", e.getMessage(), e);
            } catch (NullPointerException e){
                Log.e("AlsoError", e.getMessage(), e);
            }
            mScoreInfo.setText(forecastStr.substring(3,forecastStr.length()));
//        }
//        else{
//            mScoreInfo.setText("Hala Madrid");
//        }


    }
}
