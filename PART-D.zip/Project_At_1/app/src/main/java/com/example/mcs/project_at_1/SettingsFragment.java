package com.example.mcs.project_at_1;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.EditTextPreference;
import android.preference.ListPreference;
import android.preference.Preference;
import android.preference.PreferenceFragment;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;


public class SettingsFragment extends PreferenceFragment
        implements Preference.OnPreferenceChangeListener {



    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.pref_general);
        Preference team1Preference = findPreference("team1");
        Preference team2Preference = findPreference("team2");
        Preference leaguePreference     = findPreference("league");
        Preference languagePreference     = findPreference("language");

        team1Preference.setOnPreferenceChangeListener(this);
        team2Preference.setOnPreferenceChangeListener(this);
        leaguePreference.setOnPreferenceChangeListener(this);
        languagePreference.setOnPreferenceChangeListener(this);

        SharedPreferences team_prefs =  PreferenceManager.getDefaultSharedPreferences(this.getActivity().getApplicationContext());
        onPreferenceChange(team1Preference, team_prefs.getString(team1Preference.getKey(),""));
        team1Preference.setSummary(team_prefs.getString("team1", "Reading"));


        SharedPreferences team2_prefs =  PreferenceManager.getDefaultSharedPreferences(this.getActivity().getApplicationContext());
        onPreferenceChange(team2Preference, team2_prefs.getString(team2Preference.getKey(),""));
        team2Preference.setSummary(team_prefs.getString("team2", "Brentford"));

        SharedPreferences league_prefs =  PreferenceManager.getDefaultSharedPreferences(this.getActivity().getApplicationContext());
        onPreferenceChange(leaguePreference, league_prefs.getString(leaguePreference.getKey(),""));
        leaguePreference.setSummary(team_prefs.getString("league", "England Championship"));

        SharedPreferences language_prefs =  PreferenceManager.getDefaultSharedPreferences(this.getActivity().getApplicationContext());
        onPreferenceChange(languagePreference, language_prefs.getString(languagePreference.getKey(),""));
        languagePreference.setSummary(team_prefs.getString("language", "English"));

        String getLanguage = language_prefs.getString("language", "english");

        if(getLanguage.equals("urdu")) {
            team1Preference.setTitle(R.string.away_team_urdu);
            team2Preference.setTitle(R.string.home_team_urdu);
            leaguePreference.setTitle(R.string.choose_urdu);
            languagePreference.setTitle(R.string.lang_urdu);
        }
        else if(getLanguage.equals("english")){
            team1Preference.setTitle(R.string.away_team);
            team2Preference.setTitle(R.string.home_team);
            leaguePreference.setTitle(R.string.choose);
            languagePreference.setTitle(R.string.lang);
        }




    }

    @Override
    public boolean onPreferenceChange(Preference preference, Object value) {
        String stringValue = value.toString();

        if (preference instanceof ListPreference) {

            ListPreference listPreference = (ListPreference) preference;
            int            prefIndex      = listPreference.findIndexOfValue(stringValue);

            if (prefIndex >= 0) {
                preference.setSummary(listPreference.getEntries()[prefIndex]);
            }
        } else {
            preference.setSummary(stringValue);
        }
        return true;
    }

    }
