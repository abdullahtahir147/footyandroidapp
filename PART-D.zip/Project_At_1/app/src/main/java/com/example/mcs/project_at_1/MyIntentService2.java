package com.example.mcs.project_at_1;

import android.app.IntentService;
import android.content.Intent;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * An {@link IntentService} subclass for handling asynchronous task requests in
 * a service on a separate handler thread.
 * <p>
 * TODO: Customize class - update intent actions, extra parameters and static
 * helper methods.
 */
public class MyIntentService2 extends IntentService {
    // TODO: Rename actions, choose action names that describe tasks that this
    // IntentService can perform, e.g. ACTION_FETCH_NEW_ITEMS
    private static final String ACTION_FOO = "com.example.mcs.project_at_1.action.FOO";
    private static final String ACTION_BAZ = "com.example.mcs.project_at_1.action.BAZ";

    // TODO: Rename parameters
    private static final String EXTRA_PARAM1 = "com.example.mcs.project_at_1.extra.PARAM1";
    private static final String EXTRA_PARAM2 = "com.example.mcs.project_at_1.extra.PARAM2";

    public MyIntentService2() {
        super("MyIntentService2");
    }



    @Override
    protected void onHandleIntent(Intent intent) {
        HttpURLConnection urlConnection   = null;
        BufferedReader reader          = null;
        String 		     JsonStr = null;

        Bundle getBundle = intent.getBundleExtra("bundle");
        String urlString = getBundle.getString("URL");
        int getPosition = getBundle.getInt("position");

        try {
            URL weatherURL = new URL(urlString);
            urlConnection  = (HttpURLConnection) weatherURL.openConnection();
            urlConnection.setRequestMethod("GET");
            urlConnection.connect();

            InputStream inputStream = urlConnection.getInputStream();
            StringBuffer buffer     = new StringBuffer();

            if (inputStream != null) {
                reader = new BufferedReader(new InputStreamReader(inputStream));

                String line;
                while ((line = reader.readLine()) != null) {
                    buffer.append(line + "\n");
                }
                if (buffer.length() != 0) {
                    JsonStr = buffer.toString();
                }
            }
        } catch (IOException e) {
            Log.e("MainActivity", "Error ", e);
        } finally{
            if (urlConnection != null) {
                urlConnection.disconnect();
            }
            if (reader != null) {
                try {
                    reader.close();
                } catch (final IOException e) {
                    Log.e("MainActivity", "Error closing stream", e);
                }
            }
        }


        try {
            Intent goReceiver = new Intent("com.example.mcs.project_at_1.MyReceiver2");
            Bundle bundle = new Bundle();
            bundle.putStringArray("json2", FromJson(JsonStr, getPosition));
            goReceiver.putExtra("intent2", bundle);
            sendBroadcast(goReceiver);
//
//             return getDataFromJson(JsonStr);

        } catch (JSONException e) {
            Log.e("FetchWeatherTask11", e.getMessage(), e);
        } catch (NullPointerException e){
            Log.e("FetchTask11", e.getMessage(), e);
        }
    }


    private String[] FromJson(String JsonStr2, int position)
            throws JSONException {


        final String API_TeamName = "team_name";
        final String API_LeaguePosition = "overall_league_position";
        final String API_Wins  ="overall_league_W";
        final String API_Draw = "overall_league_D";
        final String API_Lose =  "overall_league_L";
        final String API_Points = "overall_league_PTS";
        final String API_Played = "overall_league_payed";


        JSONArray jArray2 = new JSONArray(JsonStr2);

        String[] Strs = new String[jArray2.length()];
        int k;
//        for(int i = 0; i < jArray2.length(); i++) {


//                                       position
        JSONObject j2= jArray2.getJSONObject(position);

        String Name = j2.getString(API_TeamName);
        int matches_played  = j2.getInt(API_Played);
        int matches_won = j2.getInt(API_Wins);
        int matches_loses = j2.getInt(API_Lose);
        int matches_drawn = j2.getInt(API_Draw);
        int totalpoints     = j2.getInt(API_Points);

//            k= i+1;
        Strs[0] ="Matches Played - " + matches_played;
        Strs[1] = "Matches Won - " + matches_won ;
        Strs[2] = "Matches Lost - " + matches_loses;
        Strs[3] = "Matches Drawn - " + matches_drawn ;
        Strs[4] = "Total Points - " + totalpoints;
//        }

        return Strs;
    }

}
