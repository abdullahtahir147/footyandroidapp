package com.example.mcs.project_at_1;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

public class ScoreHolder extends RecyclerView.ViewHolder
        implements View.OnClickListener {

    private  ListItemClickListener mListener;
    public TextView listItemScore;

    public ScoreHolder(@NonNull View itemView, ListItemClickListener listener) {
        super(itemView);
        listItemScore = (TextView) itemView.findViewById(R.id.live_text);
        mListener            = listener;
        itemView.setOnClickListener(this);

    }



    @Override
    public void onClick(View v) {
        int clickedPosition = getAdapterPosition();
        mListener.onListItemClick(clickedPosition);
    }

    void bind(String s) {

        listItemScore.setText(s);
    }
}
