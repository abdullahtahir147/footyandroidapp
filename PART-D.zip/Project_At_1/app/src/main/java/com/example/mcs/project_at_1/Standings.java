package com.example.mcs.project_at_1;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.TextView;

public class Standings extends AppCompatActivity {
    public static String[] answer = {""};
    Adapter dAdapter;

    private TextView HomeTeam;
    private TextView AwayTeam;
    private TextView HomeScore;
    private TextView AwayScore;
    private TextView Date;
    private TextView first;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.standings);

       HomeTeam = findViewById(R.id.textView);
        AwayTeam = findViewById(R.id.textView4);
        HomeScore = findViewById(R.id.SH);
       AwayScore = findViewById(R.id.SA);
        Date = findViewById(R.id.textView3);




        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        String team1 = prefs.getString("team1", "Reading");

        SharedPreferences prefs2 = PreferenceManager.getDefaultSharedPreferences(this);
        String team2 = prefs.getString("team2", "Brentford");

        String test=fix(team1);
        String test2= fix(team2);
        Log.v("HATA",test);

        String URLString = "https://apifootball.com/api/?action=get_H2H&firstTeam=" + test +"&secondTeam="+test2+"&APIkey=31f3ab8b35f9cba898baae6868908741cf2d855b04af85b033220142dec20886";
        FetchTask3 Task3 = new FetchTask3(answer, this.getApplicationContext());
        Task3.execute(URLString);

        Intent goServiceOne = new Intent(Standings.this, MyIntentService3.class);
        goServiceOne.putExtra("URL", URLString);
        this.startService(goServiceOne);

        try{
           HomeTeam.setText(answer[0]);
            AwayTeam.setText(answer[1]);
            HomeScore.setText(answer[2]);
            AwayScore.setText(answer[3]);
            Date.setText(answer[4]);



        }catch (ArrayIndexOutOfBoundsException e){
            Log.e("ERROR", e.getMessage(), e);
        } catch (NullPointerException e){
            Log.e("AlsoError", e.getMessage(), e);
        }

        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        String language = preferences.getString("language", "english");

        TextView textView = findViewById(R.id.textView2);
        TextView loading = findViewById(R.id.textView3);



        if(language.toLowerCase().equals("urdu")) {
            loading.setText(R.string.loader_urdu);
        }
        else{
            loading.setText(R.string.loader);
        }


        changeLanguageStandingsBottom(textView, language);


    }

    private void changeLanguageStandingsBottom(TextView textView, String language){
        try{
            if (language.toLowerCase().equals("urdu"))
                textView.setText(R.string.standings_bottom_urdu);
            else
                textView.setText(R.string.standings_bottom);
        } catch (NullPointerException e){
            Log.e("Standings", e.getMessage(), e);
        }
    }

    public String fix(String team){
        String dummy = null;

        if(team.contains(" ")){
           dummy =  team.replace(" ","+");

        }
        else{
            dummy= team;
        }
        return dummy;
    }
}
