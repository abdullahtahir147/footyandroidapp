package com.example.mcs.project_at_1;

import android.content.ClipData;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class Adapter extends RecyclerView.Adapter<ScoreHolder> {

    private int                   mNumberItems;
    public static String[]              items;
    private ListItemClickListener mOnClickListener;

    public Adapter(int numberOfItems, String[] itemList, ListItemClickListener listener){
        mNumberItems     = numberOfItems;
        items            = itemList;
        mOnClickListener = listener;
    }
    public ScoreHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Context        context                         = parent.getContext();
        int            layoutIdForListItem             = R.layout.live_scores;
        LayoutInflater inflater                        = LayoutInflater.from(context);
        boolean        shouldAttachToParentImmediately = false;

        View view = inflater.inflate(layoutIdForListItem, parent, shouldAttachToParentImmediately);
        ScoreHolder viewHolder = new ScoreHolder(view, mOnClickListener);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ScoreHolder holder, int position) {
        holder.bind(items[position]);
    }

    @Override
    public int getItemCount() {

        return mNumberItems;
    }


    public void setData(String[] Data) {

        items        = Data;
        mNumberItems = Data.length;
        notifyDataSetChanged();
    }
    public String getData(int clickedItemIndex){

        return items[clickedItemIndex];
    }

    public String[] getItems(){
        return items;
    }
}
