package com.example.mcs.project_at_1;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.widget.Toast;

public class NotificationUtil {
    private static final int    WATER_REMINDER_NOTIFICATION_ID         = 1138;
    private static final int    WATER_REMINDER_PENDING_INTENT_ID       = 3417;
    private static final String WATER_REMINDER_NOTIFICATION_CHANNEL_ID = "reminder_notification_channel";
    private static final int Standings =1000;

    public static void clearAllNotifications(Context context) {
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.cancelAll();
    }





    public static void remindUserBecauseCharging(Context context) {

        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel mChannel = new NotificationChannel(
                    WATER_REMINDER_NOTIFICATION_CHANNEL_ID,
                    "Primary",
                    NotificationManager.IMPORTANCE_HIGH);

            notificationManager.createNotificationChannel(mChannel);
        }
        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(context,WATER_REMINDER_NOTIFICATION_CHANNEL_ID);
        notificationBuilder
                .setColor(ContextCompat.getColor(context, R.color.colorPrimary))
                .setSmallIcon(R.drawable.button)
                .setLargeIcon(largeIcon(context))
                .setContentTitle(context.getString(R.string.Top_team))
                .setContentText(context.getString(R.string.Find_out))
                .setDefaults(Notification.DEFAULT_VIBRATE)
                .setContentIntent(contentIntent(context))
                .setAutoCancel(true);
                 notificationBuilder
                .addAction(drinkWaterAction(context))
                .addAction(ignoreReminderAction(context));

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN && Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            notificationBuilder.setPriority(NotificationCompat.PRIORITY_HIGH);
        }

        notificationManager.notify(WATER_REMINDER_NOTIFICATION_ID, notificationBuilder.build());
    }









    public static void StandingsNotification(Context context) {

        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel mChannel = new NotificationChannel(
                    WATER_REMINDER_NOTIFICATION_CHANNEL_ID,
                    "Primary",
                    NotificationManager.IMPORTANCE_HIGH);

            notificationManager.createNotificationChannel(mChannel);

        }
        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(context,WATER_REMINDER_NOTIFICATION_CHANNEL_ID);
        notificationBuilder
                .setColor(ContextCompat.getColor(context, R.color.colorAccent))
                .setSmallIcon(R.drawable.round_toll_black_18dp)
                .setLargeIcon(largeIcon2(context))
                .setContentTitle(context.getString(R.string.Last_match))
                .setContentText(context.getString(R.string.Click))
                .setDefaults(Notification.DEFAULT_VIBRATE)
                .setContentIntent(contentIntent(context))
                .setAutoCancel(true);
        notificationBuilder
                .addAction(Action(context))
                .addAction(ignoreAction(context))
                .addAction(crash(context));

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN && Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            notificationBuilder.setPriority(NotificationCompat.PRIORITY_HIGH);
        }

        notificationManager.notify(WATER_REMINDER_NOTIFICATION_ID, notificationBuilder.build());
    }











    private static NotificationCompat.Action Action(Context context) {

        Intent incrementWaterCountIntent = new Intent(context, Standings.class);
//        incrementWaterCountIntent.setAction(ReminderTasks.ACTION_INCREMENT_WATER_COUNT);

        PendingIntent incrementWaterPendingIntent = PendingIntent.getActivity(
                context,
                1,
                incrementWaterCountIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);

//        PendingIntent goHere = PendingIntent.
        NotificationCompat.Action drinkWaterAction = new NotificationCompat.Action(R.drawable.ic_local_drink_black_24px,
                "Check",
                incrementWaterPendingIntent);

        Log.v("LUMS", "issa notification");

//        context.startActivity(incrementWaterCountIntent);
        return drinkWaterAction;
    }

    private static final int    ACTION_IGNORE_INTENT_ID        = 13;

    private static NotificationCompat.Action ignoreAction(Context context) {

        Intent ignoreReminderIntent = new Intent(context, DissmissService.class);
        ignoreReminderIntent.setAction(ReminderTasks.ACTION_DISMISS_NOTIFICATION);

        PendingIntent ignoreReminderPendingIntent = PendingIntent.getService(
                context,
                ACTION_IGNORE_PENDING_INTENT_ID,
                ignoreReminderIntent,
                PendingIntent.FLAG_CANCEL_CURRENT);

        NotificationCompat.Action ignoreReminderAction = new NotificationCompat.Action(R.drawable.ic_cancel_black_24px,
                "Don't care ",
                ignoreReminderPendingIntent);

        return ignoreReminderAction;
    }

    private static NotificationCompat.Action crash(Context context) {


        Intent ignoreReminderIntent = new Intent(context, CrashMe.class);
        ignoreReminderIntent.setAction(ReminderTasks.ACTION_DISMISS_NOTIFICATION);

        PendingIntent ignoreReminderPendingIntent = PendingIntent.getActivity(
                context,
                ACTION_IGNORE_INTENT_ID,
                ignoreReminderIntent,
                PendingIntent.FLAG_CANCEL_CURRENT);

        NotificationCompat.Action ignoreReminderAction = new NotificationCompat.Action(R.drawable.ic_cancel_black_24px,
                "Crash",
                ignoreReminderPendingIntent);

        return ignoreReminderAction;
    }











    private static final int    ACTION_IGNORE_PENDING_INTENT_ID        = 14;

    private static NotificationCompat.Action ignoreReminderAction(Context context) {

        Intent ignoreReminderIntent = new Intent(context, DissmissService.class);
        ignoreReminderIntent.setAction(ReminderTasks.ACTION_DISMISS_NOTIFICATION);

        PendingIntent ignoreReminderPendingIntent = PendingIntent.getService(
                context,
                ACTION_IGNORE_PENDING_INTENT_ID,
                ignoreReminderIntent,
                PendingIntent.FLAG_CANCEL_CURRENT);

        NotificationCompat.Action ignoreReminderAction = new NotificationCompat.Action(R.drawable.ic_cancel_black_24px,
                "No, thanks.",
                ignoreReminderPendingIntent);

        return ignoreReminderAction;
    }




    private static final int    ACTION_DRINK_PENDING_INTENT_ID         = 1;

    private static NotificationCompat.Action drinkWaterAction(Context context) {

        Intent incrementWaterCountIntent = new Intent(context, MainActivity.class);
//        incrementWaterCountIntent.setAction(ReminderTasks.ACTION_INCREMENT_WATER_COUNT);

        PendingIntent incrementWaterPendingIntent = PendingIntent.getActivity(
                context,
                1,
                incrementWaterCountIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);

//        PendingIntent goHere = PendingIntent.
        NotificationCompat.Action drinkWaterAction = new NotificationCompat.Action(R.drawable.ic_local_drink_black_24px,
                "Welcome",
                incrementWaterPendingIntent);

        Log.v("LUMS", "issa notification");

//        context.startActivity(incrementWaterCountIntent);
        return drinkWaterAction;
    }

    private static PendingIntent contentIntent(Context context) {
        Intent startActivityIntent = new Intent(context, MainActivity.class);

//        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANN)
        Log.v("LUMS", "still a notification request");
        return PendingIntent.getActivity(
                context,
                0,
                startActivityIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private static Bitmap largeIcon(Context context) {

        Resources res       = context.getResources();
        Bitmap    largeIcon = BitmapFactory.decodeResource(res, R.drawable.round_check_circle_outline_black_18dp);
        return largeIcon;
    }

    private static Bitmap largeIcon2(Context context) {

        Resources res       = context.getResources();
        Bitmap    largeIcon = BitmapFactory.decodeResource(res, R.drawable.round_toll_black_18dp);
        return largeIcon;
    }
}
