package com.example.mcs.project_at_1;

public interface ListItemClickListener {
    void onListItemClick (int clickedItemIndex);
}