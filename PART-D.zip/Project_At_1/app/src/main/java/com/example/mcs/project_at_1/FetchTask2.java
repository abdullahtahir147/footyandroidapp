package com.example.mcs.project_at_1;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.preference.PreferenceManager;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class FetchTask2 extends AsyncTask<String, Void, String[]> {
    Adapter cAdapter;
    Context cContext;
    int position;

    String[] returnResults;
    public FetchTask2(String[] results, Context context, int position) {
        returnResults = results;
        cContext = context;
        this.position = position;
    }
    @Override
    protected String[] doInBackground(String... urlStrings) {

        HttpURLConnection urlConnection   = null;
        BufferedReader reader          = null;
        String 		     JsonStr2 = null;

        try {
            URL weatherURL = new URL(urlStrings[0]);
            urlConnection  = (HttpURLConnection) weatherURL.openConnection();
            urlConnection.setRequestMethod("GET");
            urlConnection.connect();

            InputStream inputStream = urlConnection.getInputStream();
            StringBuffer buffer     = new StringBuffer();

            if (inputStream != null) {
                reader = new BufferedReader(new InputStreamReader(inputStream));

                String line;
                while ((line = reader.readLine()) != null) {
                    buffer.append(line + "\n");
                }
                if (buffer.length() != 0) {
                    JsonStr2 = buffer.toString();
                }
            }
        } catch (IOException e) {
            Log.e("MainActivity", "Error ", e);
        } finally{
            if (urlConnection != null) {
                urlConnection.disconnect();
            }
            if (reader != null) {
                try {
                    reader.close();
                } catch (final IOException e) {
                    Log.e("MainActivity", "Error closing stream", e);
                }
            }
        }

        try {
            return FromJson(JsonStr2);
        } catch (JSONException e) {
            Log.e("FetchWeatherTask11", e.getMessage(), e);
        } catch (NullPointerException e){
            Log.e("FetchTask11", e.getMessage(), e);
        }

        // This will only happen if there was an error getting or parsing the forecast.
        return null;
    }

    @Override
    protected void onPostExecute(String[] strings) {
        super.onPostExecute(strings);
        Events.results = strings;
        Log.v("FSDF", strings[0]);
    }

    private String[] FromJson(String JsonStr2)
            throws JSONException {


        final String API_TeamName = "team_name";
        final String API_LeaguePosition = "overall_league_position";
        final String API_Wins  ="overall_league_W";
        final String API_Draw = "overall_league_D";
        final String API_Lose =  "overall_league_L";
        final String API_Points = "overall_league_PTS";
        final String API_Played = "overall_league_payed";

        SharedPreferences prefs       = PreferenceManager.getDefaultSharedPreferences(cContext);
        String            tempUnit    = prefs.getString("units", "metric");

//        JSONObject Json  = new JSONObject(JsonStr.substring(1,JsonStr.length()-1));
        JSONObject getter  ;

        JSONArray jArray2 = new JSONArray(JsonStr2);

        String[] Strs = new String[jArray2.length()];
        int k;
//        for(int i = 0; i < jArray2.length(); i++) {



            JSONObject j2= jArray2.getJSONObject(position);

            String Name = j2.getString(API_TeamName);
            int matches_played  = j2.getInt(API_Played);
            int matches_won = j2.getInt(API_Wins);
            int matches_loses = j2.getInt(API_Lose);
            int matches_drawn = j2.getInt(API_Draw);
            int totalpoints     = j2.getInt(API_Points);

//            k= i+1;
            Strs[0] ="Matches Played - " + matches_played;
            Strs[1] = "Matches Won - " + matches_won ;
            Strs[2] = "Matches Lost - " + matches_loses;
            Strs[3] = "Matches Drawn - " + matches_drawn ;
            Strs[4] = "Total Points - " + totalpoints;
//        }

        return Strs;
    }
}

