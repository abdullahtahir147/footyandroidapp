package com.example.mcs.project_at_1;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.preference.PreferenceManager;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class FetchTask3 extends AsyncTask<String, Void, String[]> {
    Adapter mAdapter;
    Context mContext;
    String [] returnAnswer;

    public FetchTask3(String[] answer, Context context) {
        returnAnswer = answer;
        mContext        = context;
    }


    @Override
    protected String[] doInBackground(String... urlStrings) {

        HttpURLConnection urlConnection   = null;
        BufferedReader reader          = null;
        String 		     JsonStr = null;

        try {
            URL weatherURL = new URL(urlStrings[0]);
            urlConnection  = (HttpURLConnection) weatherURL.openConnection();
            urlConnection.setRequestMethod("GET");
            urlConnection.connect();

            InputStream inputStream = urlConnection.getInputStream();
            StringBuffer buffer     = new StringBuffer();

            if (inputStream != null) {
                reader = new BufferedReader(new InputStreamReader(inputStream));

                String line;
                while ((line = reader.readLine()) != null) {
                    buffer.append(line + "\n");
                }
                if (buffer.length() != 0) {
                    JsonStr = buffer.toString();
                }
            }
        } catch (IOException e) {
            Log.e("MainActivity", "Error ", e);
        } finally{
            if (urlConnection != null) {
                urlConnection.disconnect();
            }
            if (reader != null) {
                try {
                    reader.close();
                } catch (final IOException e) {
                    Log.e("MainActivity", "Error closing stream", e);
                }
            }
        }

        try {

//
            return getDataFromJson(JsonStr);
        } catch (JSONException e) {
            Log.e("FetchWeatherTask11", e.getMessage(), e);
        } catch (NullPointerException e){
            Log.e("FetchTask11", e.getMessage(), e);
        } catch (ArrayIndexOutOfBoundsException e){
            Log.e("Fetch", e.getMessage(), e);
        }

        // This will only happen if there was an error getting or parsing the forecast.
        return null;
    }
    @Override
    protected void onPostExecute(String[] something) {
        super.onPostExecute(something);
        Standings.answer = something;
//        Log.v("FSDF", something[0]);
    }


    private String[] getDataFromJson(String JsonStr3)
            throws JSONException, ArrayIndexOutOfBoundsException  {


        final String API_HomeTeam = "match_hometeam_name";
        final String API_AwayTeam = "match_awayteam_name";
        final String API_HomeScore = "match_hometeam_score";
        final String API_AwayScore =  "match_awayteam_score";
        final String API_Date = "match_date";


        final String API_LIST  = "list";
        final String API_match  = "firstTeam_VS_secondTeam";



        JSONObject forecastJson  = new JSONObject(JsonStr3);
        JSONArray  matchArray  = forecastJson.getJSONArray(API_match);



        String[] resultStrs = new String[matchArray.length()];


//            JSONObject first = matchArray.getJSONObject(0);
            JSONObject  arrayObject  =  matchArray.getJSONObject(0);
            String Home = arrayObject.getString(API_HomeTeam);
            String Away = arrayObject.getString(API_AwayTeam);
            String Scorehome = arrayObject.getString(API_HomeScore);
            String ScoreAway = arrayObject.getString(API_AwayScore);
            String Date = arrayObject.getString(API_Date);

        resultStrs[0] ="Home Team - " +Home;
        resultStrs[1] = "Away Team - " + Away ;
        resultStrs[2] = "Home Team Score - " + Scorehome;
        resultStrs[3] = "Away Team Score - " +ScoreAway ;
        resultStrs[4] = "Date Played - " + Date ;

        Log.v("HELLLPP", resultStrs[0]);
        return resultStrs;
  }

}
