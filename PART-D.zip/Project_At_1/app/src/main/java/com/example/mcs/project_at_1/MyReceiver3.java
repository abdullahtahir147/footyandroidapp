package com.example.mcs.project_at_1;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

public class MyReceiver3 extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {

        Bundle bundle = intent.getBundleExtra("intent3");
        String[] stringArray3= bundle.getStringArray("json3");

        Standings.answer = stringArray3;
    }
}
