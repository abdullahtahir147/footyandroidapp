package com.example.mcs.project_at_1;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

public class MyReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        //Pass to adapter
        Bundle bundle = intent.getBundleExtra("intent");
        String[] stringArray = bundle.getStringArray("json");

        Adapter.items = stringArray;
        MainActivity.mAdapter.notifyDataSetChanged();
    }
}
