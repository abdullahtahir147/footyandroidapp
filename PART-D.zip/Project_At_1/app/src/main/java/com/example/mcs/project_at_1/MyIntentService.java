package com.example.mcs.project_at_1;

import android.app.IntentService;
import android.content.Intent;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * An {@link IntentService} subclass for handling asynchronous task requests in
 * a service on a separate handler thread.
 * <p>
 * TODO: Customize class - update intent actions, extra parameters and static
 * helper methods.
 */
public class MyIntentService extends IntentService {

    public MyIntentService() {
        super("MyIntentService");
    }



    @Override
    protected void onHandleIntent(Intent intent) {

//        String action = intent.getAction();
//        ReminderTasks.executeTask(this, action);



        HttpURLConnection urlConnection   = null;
        BufferedReader reader          = null;
        String 		     JsonStr = null;

        try {
            URL weatherURL = new URL(intent.getStringExtra("URL"));
            urlConnection  = (HttpURLConnection) weatherURL.openConnection();
            urlConnection.setRequestMethod("GET");
            urlConnection.connect();

            InputStream inputStream = urlConnection.getInputStream();
            StringBuffer buffer     = new StringBuffer();

            if (inputStream != null) {
                reader = new BufferedReader(new InputStreamReader(inputStream));

                String line;
                while ((line = reader.readLine()) != null) {
                    buffer.append(line + "\n");
                }
                if (buffer.length() != 0) {
                    JsonStr = buffer.toString();
                }
            }
        } catch (IOException e) {
            Log.e("MainActivity", "Error ", e);
        } finally{
            if (urlConnection != null) {
                urlConnection.disconnect();
            }
            if (reader != null) {
                try {
                    reader.close();
                } catch (final IOException e) {
                    Log.e("MainActivity", "Error closing stream", e);
                }
            }
        }


        try {
        Intent goReceiver = new Intent("com.example.mcs.project_at_1.MyReceiver");
        Bundle bundle = new Bundle();
        bundle.putStringArray("json", getDataFromJson(JsonStr));
        goReceiver.putExtra("intent", bundle);
        sendBroadcast(goReceiver);
//
//             return getDataFromJson(JsonStr);

        } catch (JSONException e) {
            Log.e("FetchWeatherTask11", e.getMessage(), e);
        } catch (NullPointerException e){
            Log.e("FetchTask11", e.getMessage(), e);
        }
    }

    private String[] getDataFromJson(String JsonStr)
            throws JSONException {


        final String API_TeamName = "team_name";
        final String API_LeaguePosition = "overall_league_position";
        final String API_Wins  ="overall_league_W";
        final String API_Draw = "overall_league_D";
        final String API_Lose =  "overall_league_L";
        final String API_Points = "overall_league_PTS";
        final String API_Played = "overall_league_payed";

//        JSONObject Json  = new JSONObject(JsonStr.substring(1,JsonStr.length()-1));
        JSONObject getter  ;

        JSONArray jArray = new JSONArray(JsonStr);

        String[] resultStrs = new String[jArray.length()];
        int k;
        for(int i = 0; i < jArray.length(); i++) {
            JSONObject j = jArray.getJSONObject(i);

            String Name = j.getString(API_TeamName);

            k = i+1;
            resultStrs[i] =k  + " - " +Name ;
//            " - " +matches_played+  " - " +matches_won+  " - " + matches_loses+  " - " +matches_drawn+  " - " +totalpoints ;

        }
        Log.v("HELLLPP", resultStrs[0]);
        return resultStrs;
    }

}
