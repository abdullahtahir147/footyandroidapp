package com.example.mcs.project_at_1;

import android.app.IntentService;
import android.content.Intent;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * An {@link IntentService} subclass for handling asynchronous task requests in
 * a service on a separate handler thread.
 * <p>
 * TODO: Customize class - update intent actions, extra parameters and static
 * helper methods.
 */
public class MyIntentService3 extends IntentService {
    // TODO: Rename actions, choose action names that describe tasks that this
    // IntentService can perform, e.g. ACTION_FETCH_NEW_ITEMS
    private static final String ACTION_FOO = "com.example.mcs.project_at_1.action.FOO";
    private static final String ACTION_BAZ = "com.example.mcs.project_at_1.action.BAZ";

    // TODO: Rename parameters
    private static final String EXTRA_PARAM1 = "com.example.mcs.project_at_1.extra.PARAM1";
    private static final String EXTRA_PARAM2 = "com.example.mcs.project_at_1.extra.PARAM2";

    public MyIntentService3() {
        super("MyIntentService3");
    }



    @Override
    protected void onHandleIntent(Intent intent) {
        HttpURLConnection urlConnection   = null;
        BufferedReader reader          = null;
        String 		     JsonStr = null;

        try {
            URL weatherURL = new URL(intent.getStringExtra("URL"));
            urlConnection  = (HttpURLConnection) weatherURL.openConnection();
            urlConnection.setRequestMethod("GET");
            urlConnection.connect();

            InputStream inputStream = urlConnection.getInputStream();
            StringBuffer buffer     = new StringBuffer();

            if (inputStream != null) {
                reader = new BufferedReader(new InputStreamReader(inputStream));

                String line;
                while ((line = reader.readLine()) != null) {
                    buffer.append(line + "\n");
                }
                if (buffer.length() != 0) {
                    JsonStr = buffer.toString();
                }
            }
        } catch (IOException e) {
            Log.e("MainActivity", "Error ", e);
        } finally{
            if (urlConnection != null) {
                urlConnection.disconnect();
            }
            if (reader != null) {
                try {
                    reader.close();
                } catch (final IOException e) {
                    Log.e("MainActivity", "Error closing stream", e);
                }
            }
        }


        try {
            Intent goReceiver = new Intent("com.example.mcs.project_at_1.MyReceiver3");
            Bundle bundle = new Bundle();
            bundle.putStringArray("json3", getDataFromJson(JsonStr));
            goReceiver.putExtra("intent3", bundle);
            sendBroadcast(goReceiver);
//
//             return getDataFromJson(JsonStr);

        } catch (JSONException e) {
            Log.e("FetchWeatherTask11", e.getMessage(), e);
        } catch (NullPointerException e){
            Log.e("FetchTask11", e.getMessage(), e);
        }

    }

    private String[] getDataFromJson(String JsonStr3)
            throws JSONException, ArrayIndexOutOfBoundsException  {


        final String API_HomeTeam = "match_hometeam_name";
        final String API_AwayTeam = "match_awayteam_name";
        final String API_HomeScore = "match_hometeam_score";
        final String API_AwayScore =  "match_awayteam_score";
        final String API_Date = "match_date";


        final String API_LIST  = "list";
        final String API_match  = "firstTeam_VS_secondTeam";



        JSONObject forecastJson  = new JSONObject(JsonStr3);
        JSONArray matchArray  = forecastJson.getJSONArray(API_match);



        String[] resultStrs = new String[matchArray.length()];


//            JSONObject first = matchArray.getJSONObject(0);
        JSONObject  arrayObject  =  matchArray.getJSONObject(0);
        String Home = arrayObject.getString(API_HomeTeam);
        String Away = arrayObject.getString(API_AwayTeam);
        String Scorehome = arrayObject.getString(API_HomeScore);
        String ScoreAway = arrayObject.getString(API_AwayScore);
        String Date = arrayObject.getString(API_Date);

        resultStrs[0] ="Home Team - " +Home;
        resultStrs[1] = "Away Team - " + Away ;
        resultStrs[2] = "Home Team Score - " + Scorehome;
        resultStrs[3] = "Away Team Score - " +ScoreAway ;
        resultStrs[4] = "Date Played - " + Date ;

        Log.v("HELLLPP", resultStrs[0]);
        return resultStrs;
    }

}
