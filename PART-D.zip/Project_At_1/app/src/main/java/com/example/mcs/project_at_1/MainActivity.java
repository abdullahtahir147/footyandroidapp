package com.example.mcs.project_at_1;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity  implements ListItemClickListener{

    String[] Items = {"Manchester United","Juventus","Team 3","Team 4","Team 5","Team 6","Team 7","Team 8","Team 9","Team 10"};

    public static Adapter mAdapter;
    private RecyclerView mNumbersList;
    private DividerItemDecoration mDividerItemDecoration;
    String URLString = "https://apifootball.com/api/?action=get_standings&league_id=63&APIkey=31f3ab8b35f9cba898baae6868908741cf2d855b04af85b033220142dec20886";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, Standings.class);
                startActivity(intent);
            }
        });
        ReminderUtilities.scheduleChargingReminder(this);







        mNumbersList = (RecyclerView) findViewById(R.id.rv);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);

        mNumbersList.setLayoutManager(layoutManager);
        mNumbersList.setHasFixedSize(true);
        mDividerItemDecoration = new DividerItemDecoration(mNumbersList.getContext(), layoutManager.getOrientation());
        mNumbersList.addItemDecoration(mDividerItemDecoration);

        mAdapter = new Adapter(Items.length, Items, this);
        mNumbersList.setAdapter(mAdapter);








    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();


        Context context = getApplicationContext();
        int duration    = Toast.LENGTH_SHORT;


        if (id == R.id.action_settings) {

            Intent intent = new Intent(MainActivity.this, SettingsActivity.class);
            startActivity(intent);
            SharedPreferences league_prefs     = PreferenceManager.getDefaultSharedPreferences(this);
            String            league    = league_prefs.getString("league", "England Championship");

            if(league.equals("french ligue")){
                URLString = "https://apifootball.com/api/?action=get_standings&league_id=128&APIkey=31f3ab8b35f9cba898baae6868908741cf2d855b04af85b033220142dec20886";
//                FetchTask Task = new FetchTask(mAdapter, this.getApplicationContext());
                Intent goServiceOne = new Intent(MainActivity.this, MyIntentService.class);
                goServiceOne.putExtra("URL", URLString);
                this.startService(goServiceOne);
//                Task.execute(URLString);
            }
            else if(league.equals("england championship")){
                URLString = "https://apifootball.com/api/?action=get_standings&league_id=63&APIkey=31f3ab8b35f9cba898baae6868908741cf2d855b04af85b033220142dec20886";
//                FetchTask Task = new FetchTask(mAdapter, this.getApplicationContext());
//                Task.execute(URLString);
                Intent goServiceOne = new Intent(MainActivity.this, MyIntentService.class);
                goServiceOne.putExtra("URL", URLString);
                this.startService(goServiceOne);
            }



        }else if(id == R.id.action_refresh){

//            FetchTask Task = new FetchTask(mAdapter, this.getApplicationContext());
//            Task.execute(URLString);
            Intent goServiceOne = new Intent(MainActivity.this, MyIntentService.class);
            goServiceOne.putExtra("URL", URLString);
            this.startService(goServiceOne);

            SharedPreferences league_prefs     = PreferenceManager.getDefaultSharedPreferences(this);
            String            league    = league_prefs.getString("league", "England Championship");

            if(league.equals("french ligue")){
                URLString = "https://apifootball.com/api/?action=get_standings&league_id=128&APIkey=31f3ab8b35f9cba898baae6868908741cf2d855b04af85b033220142dec20886";
//                FetchTask Task2 = new FetchTask(mAdapter, this.getApplicationContext());
//                Task2.execute(URLString);

            }
            else if(league.equals("england championship")){
                URLString = "https://apifootball.com/api/?action=get_standings&league_id=63&APIkey=31f3ab8b35f9cba898baae6868908741cf2d855b04af85b033220142dec20886";
//                FetchTask Task3 = new FetchTask(mAdapter, this.getApplicationContext());
//                Task3.execute(URLString);
            }

            goServiceOne = new Intent(MainActivity.this, MyIntentService.class);
            goServiceOne.putExtra("URL", URLString);
            this.startService(goServiceOne);

            SharedPreferences language_prefs     = PreferenceManager.getDefaultSharedPreferences(this);
            String            language    = language_prefs.getString("language", "english");

            if(language.toLowerCase().equals("urdu")) {
                getSupportActionBar().setTitle(R.string.app_name_urdu);
            }
            else{
                getSupportActionBar().setTitle(R.string.app_name);
            }


        } else if (id == R.id.action_notification){
            NotificationUtil.StandingsNotification(this);
        }


            return super.onOptionsItemSelected(item);
        }

    @Override
    public void onListItemClick(int clickedItemIndex) {

        Intent Events;

        Events= new Intent(MainActivity.this, Events.class);
        Bundle extras = new Bundle();
        extras.putString("team", mAdapter.getData(clickedItemIndex));
        extras.putString("number", "" + clickedItemIndex);
        Events.putExtras(extras);
//        Events.putExtra(Intent.EXTRA_TEXT,  mAdapter.getData(clickedItemIndex));
//        Events.putExtra(Intent.EXTRA_TEXT, clickedItemIndex);

        startActivity(Events);
    }


    public void testNotification(View view) {
        NotificationUtil.remindUserBecauseCharging(this);
    }


    public void testNotification2(View view) {
        NotificationUtil.StandingsNotification(this);
    }
}
