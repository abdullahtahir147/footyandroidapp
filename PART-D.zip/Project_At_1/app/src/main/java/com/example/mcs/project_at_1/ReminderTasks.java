package com.example.mcs.project_at_1;

import android.content.Context;

public class ReminderTasks {
    public static final String ACTION_INCREMENT_WATER_COUNT = "increment-water-count";
    public static final String ACTION_DISMISS_NOTIFICATION  = "dismiss-notification";
    public static final String ACTION_CHARGING_REMINDER     = "charging-reminder";

    public static void executeTask(Context context, String action){
        if (ACTION_INCREMENT_WATER_COUNT.equals(action)){
            incrementWaterCount(context);
        }
        else if (ACTION_DISMISS_NOTIFICATION.equals(action)){
            NotificationUtil.clearAllNotifications(context);
        }
        else if (ACTION_CHARGING_REMINDER.equals(action)){

            issueChargingReminder(context);
        }
    }
    private static void incrementWaterCount(Context context){

        NotificationUtil.clearAllNotifications(context);
    }

    private static void issueChargingReminder(Context context) {
      ;
        NotificationUtil.remindUserBecauseCharging(context);
    }
}
