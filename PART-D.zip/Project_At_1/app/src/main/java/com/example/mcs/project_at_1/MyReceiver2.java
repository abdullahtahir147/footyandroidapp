package com.example.mcs.project_at_1;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

public class MyReceiver2 extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        // TODO: This method is called when the BroadcastReceiver is receiving
        // an Intent broadcast.

        Bundle bundle = intent.getBundleExtra("intent2");
        String[] stringArray2= bundle.getStringArray("json2");

        Events.results= stringArray2;


    }
}
